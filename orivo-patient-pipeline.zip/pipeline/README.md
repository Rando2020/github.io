# Orivo Patient Pipeline — Pilot One

SMS-first, human-in-the-loop medication communication for one pilot pharmacy.
No app, no portal, no EHR integration required to start. A CSV roster and a
Twilio number are enough to prove or disprove the concept.

## What this is

```
Patient texts  ->  Twilio  ->  /sms webhook
                                 |- consent state machine (YES / STOP)
                                 |- triage: emergency? barrier? question?
                                 |    |- emergency  -> immediate 911 reply + staff alert
                                 |    '- all else   -> acknowledgment + reviewer queue
                                 '- audit log of everything
Pharmacist reviews /queue  ->  approves or edits the drafted reply  ->  sent
/metrics  ->  the numbers that make this fundable (or tell you to pivot)
```

Three pilot use cases, plus the two most common urban access barriers:
new-start education (`what_for`), affordability (`cost`), side-effect
escalation (`side_effect`), transit/ride barriers (`transport`), and
pharmacy hours/access (`pharmacy_access`).

## Quick start (sandbox)

```bash
pip install -r requirements.txt
cp .env.example .env          # fill in Twilio credentials
uvicorn app.main:app --reload --port 8000
ngrok http 8000               # set Twilio number webhook to https://<ngrok>/sms
```

Enroll a test roster (start with your own phone):

```bash
python -m app.enroll roster.example.csv --dry-run   # preview
python -m app.enroll roster.example.csv             # sends consent texts
```

Reviewer workflow (curl for now; a one-page internal UI comes later):

```bash
curl localhost:8000/queue
curl -X POST "localhost:8000/queue/<case_id>/resolve?reviewer=ziah&final_reply=..."
curl localhost:8000/metrics
```

## Hard gates before any real patient

Do these in order. None are optional.

1. **Twilio BAA signed** before any message that could contain PHI.
2. **A2P 10DLC sender registration** completed (carriers filter unregistered
   traffic; healthcare use cases get reviewed).
3. **Consent**: only text numbers from a partner roster where TCPA-compliant
   consent is captured; this app's YES/STOP flow plus Twilio Advanced Opt-Out
   handles the mechanics, but the *pharmacy* relationship is the consent basis.
4. **Pilot agreement** with the pharmacy covering data handling, escalation
   responsibility, and who the responding pharmacist is.
5. **Move off SQLite/laptop**: deploy to a HIPAA-eligible environment (e.g.
   AWS under BAA) with HTTPS, secrets in a manager, and Postgres.
6. **Signature validation stays on** (`VALIDATE_TWILIO_SIGNATURES=true`).

Until all six are done, test only with your own phones and synthetic rosters.

## The metrics that prove the concept

`/metrics` is deliberately small. For the pilot report you want:

- **Consent rate**: granted / enrolled (does the population opt in at all?)
- **Engagement**: patients with ≥1 inbound message
- **Barriers surfaced**: cost + transport + pharmacy_access cases — this is
  the SDOH data story no claims feed captures
- **Refill saves**: refill cases resolved before a therapy gap
- **The headline number** (measured at the pharmacy, not in this app):
  pickup rate / PDC for the texted cohort vs. the pharmacy's baseline

That last comparison is the slide that gets you grant money or tells you to
change course. Design the cohort with the pharmacist before sending text one.

## Adding the model later

`triage.py` ships with deterministic classification and templated drafts on
purpose: it's auditable, free, and good enough to start. When you add an LLM,
replace the internals of `classify()`/`draft_reply()` only — the contract
(drafts are suggestions; a human approves anything substantive; everything is
audit-logged with a model version) must not change. That contract *is* the
clinical-safety story you'll tell partners and reviewers.

## Layout

```
app/main.py     webhook + reviewer API
app/triage.py   intent classification + draft suggestions (EN/ES)
app/replies.py  patient-facing templates incl. consent + emergency
app/db.py       SQLite schema, consent state, audit logging
app/enroll.py   CSV roster -> consent texts
```
