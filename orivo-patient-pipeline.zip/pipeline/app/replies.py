"""
Patient-facing message templates — pilot one (EN/ES).

Rules these templates follow:
  - Plain language, low reading level, no jargon.
  - Every outbound thread includes opt-out language at consent and respects
    STOP immediately (Twilio Advanced Opt-Out also enforces this at the
    carrier level — belt and suspenders).
  - The emergency reply is the ONLY clinically-toned message ever auto-sent
    without human review, and it does one job: route to 911.
  - {pharmacy} is the pilot partner's name so texts feel local and trusted,
    not like a random number.
"""

CONSENT_REQUEST = {
    "en": ("{pharmacy}: Hi! We can text you about your new medication — answers to "
           "questions, refill reminders, and help with cost or pickup. Reply YES to "
           "join. Msg&data rates may apply. Reply STOP anytime to quit, HELP for help."),
    "es": ("{pharmacy}: ¡Hola! Podemos enviarle mensajes sobre su nuevo medicamento: "
           "respuestas a preguntas, recordatorios de resurtido y ayuda con costos o "
           "recogida. Responda SI para participar. Pueden aplicar tarifas. Responda "
           "STOP para salir, AYUDA para ayuda."),
}

CONSENT_CONFIRMED = {
    "en": ("You're in! Text us anytime about your medication — questions like "
           "\"what is this for?\", \"I can't afford this\", or \"this side effect "
           "worries me\" are all okay. A real person reviews every message. "
           "Reply STOP anytime to quit."),
    "es": ("¡Listo! Envíenos un mensaje cuando quiera sobre su medicamento — preguntas "
           "como \"¿para qué es esto?\", \"no puedo pagarlo\" o \"este efecto me "
           "preocupa\" están bien. Una persona real revisa cada mensaje. Responda "
           "STOP para salir."),
}

OPT_OUT_CONFIRMED = {
    "en": ("You've been unsubscribed and won't get more texts from us. Your pharmacy "
           "is still there for you in person or by phone anytime."),
    "es": ("Ha sido dado de baja y no recibirá más mensajes nuestros. Su farmacia "
           "sigue disponible en persona o por teléfono cuando lo necesite."),
}

NOT_ENROLLED = {
    "en": ("This number supports patients enrolled through a partner pharmacy. If you "
           "think this is a mistake, please contact your pharmacy directly."),
    "es": ("Este número es para pacientes inscritos a través de una farmacia asociada. "
           "Si cree que esto es un error, comuníquese con su farmacia directamente."),
}

AWAITING_CONSENT = {
    "en": ("Reply YES if you'd like medication support texts from {pharmacy}, or "
           "STOP if you'd rather not. Thanks!"),
    "es": ("Responda SI si desea recibir mensajes de apoyo de {pharmacy}, o STOP si "
           "prefiere no recibirlos. ¡Gracias!"),
}

EMERGENCY_REPLY = {
    "en": ("If this is a medical emergency, call 911 right away. This texting service "
           "is not for emergencies. We've also alerted the pharmacy team to your "
           "message."),
    "es": ("Si esto es una emergencia médica, llame al 911 de inmediato. Este servicio "
           "de mensajes no es para emergencias. También hemos alertado al equipo de "
           "la farmacia sobre su mensaje."),
}

YES_WORDS = {"yes", "y", "si", "sí", "yes!", "start", "unstop"}
STOP_WORDS = {"stop", "stopall", "unsubscribe", "cancel", "end", "quit"}


def t(template: dict, language: str, **kwargs) -> str:
    return template.get(language, template["en"]).format(**kwargs)
